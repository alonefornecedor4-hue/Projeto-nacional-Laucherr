package com.projetonacional.launcher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val serverIp = "135.148.164.122"
    private val serverPort = 17270
    private val discordUrl = "https://discord.gg/J7BGPpQtP"
    private val clientPackage = "ro.alynsampmobile.launcher"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences("pnrp", MODE_PRIVATE)
        val nickname = findViewById<EditText>(R.id.nickname)
        val message = findViewById<TextView>(R.id.message)
        nickname.setText(prefs.getString("nickname", ""))

        findViewById<Button>(R.id.playButton).setOnClickListener {
            val nick = nickname.text.toString().trim()
            if (nick.length < 3) {
                nickname.error = "Digite um nickname com pelo menos 3 caracteres"
                return@setOnClickListener
            }
            prefs.edit().putString("nickname", nick).apply()
            openClient(message)
        }

        findViewById<Button>(R.id.discordButton).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(discordUrl)))
        }

        findViewById<Button>(R.id.updateButton).setOnClickListener {
            message.text = "Sistema de atualização preparado. Falta informar a URL do manifesto HTTPS."
        }
    }

    private fun openClient(message: TextView) {
        val launchIntent = packageManager.getLaunchIntentForPackage(clientPackage)
        if (launchIntent != null) {
            launchIntent.putExtra("server_ip", serverIp)
            launchIntent.putExtra("server_port", serverPort)
            startActivity(launchIntent)
            message.text = "Abrindo o cliente mobile..."
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("samp://$serverIp:$serverPort")))
        } catch (_: ActivityNotFoundException) {
            message.text = "Cliente mobile não encontrado. Instale um cliente autorizado para jogar."
        }
    }
}
