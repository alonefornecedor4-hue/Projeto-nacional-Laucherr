# Gerar o APK pelo GitHub usando o celular

## 1. Criar o repositório

1. Entre em github.com pelo navegador do celular e faça login.
2. Toque em **New repository**.
3. Use o nome `PNRP-Launcher`.
4. Selecione **Private** ou **Public**.
5. Não marque a criação automática de README, `.gitignore` ou licença.
6. Toque em **Create repository**.

## 2. Enviar os arquivos

1. Dentro do repositório, toque em **uploading an existing file** ou em **Add file > Upload files**.
2. Extraia este ZIP no celular.
3. Envie todo o conteúdo da pasta `PNRP_Launcher_MVP`, mantendo as pastas internas.
4. Confirme em **Commit changes**.

Importante: a pasta `.github/workflows` precisa ser enviada. Alguns gerenciadores de arquivos escondem pastas que começam com ponto. Ative a opção **Mostrar arquivos ocultos**.

## 3. Gerar o APK

1. Abra a aba **Actions** do repositório.
2. Selecione **Gerar APK PNRP**.
3. Toque em **Run workflow** e confirme.
4. Aguarde a execução ficar verde.
5. Abra a execução concluída.
6. Na seção **Artifacts**, baixe `PNRP-Launcher-APK`.
7. Extraia o arquivo baixado para encontrar `app-debug.apk`.

## Observações

- O primeiro APK é uma versão de teste e pode ser instalado manualmente.
- O Android pode pedir autorização para instalar aplicativos desconhecidos.
- O arquivo fica disponível nos Artifacts por 30 dias.
- Nunca envie senhas, chaves de assinatura ou arquivos secretos diretamente ao repositório público.
