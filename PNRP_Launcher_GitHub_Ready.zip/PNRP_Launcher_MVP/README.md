# PNRP Launcher Mobile — MVP 0.1

Projeto Android inicial do launcher **Projeto Nacional Roleplay**.

## Configuração atual
- Pacote: `com.projetonacional.launcher`
- Android mínimo: 8.0 (API 26)
- Servidor: `135.148.164.122:17270`
- Discord: `https://discord.gg/J7BGPpQtP`
- Cliente externo consultado: `ro.alynsampmobile.launcher`

## O que já está implementado
- Tela inicial com identidade PNRP.
- Campo de nickname com armazenamento local.
- Botão para abrir o cliente mobile.
- Fallback para URI `samp://IP:PORT`.
- Botão do Discord.
- Estrutura para verificação de atualizações.

## O que ainda precisa ser conectado
1. URL HTTPS do manifesto de atualização.
2. Formato e hospedagem dos arquivos autorizados.
3. Confirmação do método oficial suportado pelo cliente mobile para receber IP, porta e nickname.
4. Assinatura do APK e política de distribuição.
5. API opcional de notícias/status.

## Build
Abra a pasta no Android Studio, aguarde a sincronização do Gradle e use **Build > Build APK(s)**.

> O APK do cliente de terceiros não está incluído. Este projeto não modifica nem redistribui o cliente enviado.

## Compilação automática pelo GitHub

O projeto inclui `.github/workflows/build-apk.yml`. Cada envio para a branch principal compila um APK de teste. Também é possível iniciar manualmente pela aba **Actions**. Consulte `COMO_GERAR_APK_PELO_CELULAR.md`.
